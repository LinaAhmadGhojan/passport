<!DOCTYPE html>
<html>
    <head>
        <title>Welcome to our website</title>
    </head>
    <body>
        <h1> !💫Hello in website 💫!</h1>
        <p>Welcome to RS4IT
            We sending this email to you to registerin   Saudi VIAS
            </p>

            <p>  Please click on link below</p>
            <a href="{{ route('register.RS4IT') }}">{{ route('register.RS4IT') }}</a>


    </body>
</html>
