<!DOCTYPE html>
<html>
    <head>
        <title>Welcome to our website</title>
    </head>
    <body>
        <h1> !💙Hello in website 💙!</h1>
        <p>Welcome to RS4IT
            We sending this email to you to complete your Saudi VIAS entry and travel requirement

            </p>

            <p>  Please click on link below</p>
            <a href="{{ route('complete.register',['id'=> $id]) }}">{{ route('complete.register',['id'=> $id]) }}</a>


    </body>
</html>
